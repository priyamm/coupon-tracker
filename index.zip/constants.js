'use strict';

module.exports = Object.freeze({
  appId : '',
  currentCouponAPI : 'http://1indya.com/cuponsninja/json-coupon-data/',
  upcomingCouponAPI : 'http://1indya.com/cuponsninja/json-coupon-data/'
});
