'use strict';

module.exports = Object.freeze({
  appId : 'amzn1.ask.skill.ec32f324-493e-4279-953b-debcf10fddc2',
  currentCouponAPI : 'http://1indyafridays.com/json-coupon-data/',
  upcomingCouponAPI : 'http://1indyafridays.com/json-coupon-data/'
});
