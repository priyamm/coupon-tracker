const request = require('request-promise');

var data = [
      {
         "id":1267,
         "deal_type":"coupon",
         "coupon_title":"friday coupon sale",
         "coupon_code":"2546",
         "start_date":"August 10, 2017",
         "expiring_date":"August 19, 2017",
         "url":"www.groupon.com",
         "redeem_url":"tset",
         "share_url":"wwwgroupon.com",
         "longitude":"78.4867",
         "latitude":"17.3850",
         "phone":"9977028564",
         "email":"naren.darla@gmail.cm",
         "city":"inore",
         "address":"indore",
         "current_week":"true",
         "store":"www.groupon.com",
         "store_logo":"http:\/\/1indya.com\/cuponsninja\/wp-content\/uploads\/2017\/08\/logo_new_footer1-2.png",
         "store_url":"www.groupon.com",
         "category":"Food",
         "company":"Coffee",
         "steps":"test",
         "rules":"tset",
         "more_info":"tset",
         "deal_summary":"Promotional value expires Sep 10, 2017. Expires September 10, 2017. Valid only for option purchased. Ticket redeemable only for admission until expiration date, notwithstanding anything on the voucher; ticket has no value after expiration date passes. Refundable only on day of purchase through Groupon. Merchant is the issuer of ticket. Height\/physical restrictions may apply on rides. Excludes separately ticketed events and attractions. WOF reserves the right to close for private events. Attraction availability is subject to change without notice. Limit 10 per person. Merchant is solely responsible to purchasers for the care and quality of the advertised goods and services. Offer is not eligible for our promo codes or other discounts.",
         "image":"http:\/\/1indya.com\/cuponsninja\/wp-content\/uploads\/2017\/08\/section_image_narrow2-1.jpg",
         "image2":"http:\/\/1indya.com\/cuponsninja\/wp-content\/uploads\/2017\/08\/section_image_narrow2-1.jpg",
         "image3":"http:\/\/1indya.com\/cuponsninja\/wp-content\/uploads\/2017\/08\/9349758133_3797b07e2a_o-420x280-2.jpg"
      },
      {
         "id":1245,
         "deal_type":"coupon",
         "coupon_title":"couponsninja test coupon",
         "coupon_code":"250120",
         "start_date":"August 11, 2017",
         "expiring_date":"August 25, 2017",
         "url":"www.groupon.com",
         "redeem_url":"tsetse",
         "share_url":"tsetset",
         "longitude":"tset",
         "latitude":"test",
         "phone":"5435435",
         "email":"nahat@gmail.om",
         "city":"inore",
         "address":"tests",
         "current_week":"true",
         "store":"taete",
         "store_logo":"http:\/\/1indya.com\/cuponsninja\/wp-content\/uploads\/2017\/08\/section_image_narrow2-1.jpg",
         "store_url":"tsetsetset",
         "category":"Beauty",
         "company":"Harry Gordon",
         "steps":"test",
         "rules":"tset",
         "more_info":"tsetset",
         "deal_summary":"Promotional value expires Sep 10, 2017. Expires September 10, 2017. Valid only for option purchased. Ticket redeemable only for admission until expiration date, notwithstanding anything on the voucher; ticket has no value after expiration date passes. Refundable only on day of purchase through Groupon. Merchant is the issuer of ticket. Height\/physical restrictions may apply on rides. Excludes separately ticketed events and attractions. WOF reserves the right to close for private events. Attraction availability is subject to change without notice. Limit 10 per person. Merchant is solely responsible to purchasers for the care and quality of the advertised goods and services. Offer is not eligible for our promo codes or other discounts.",
         "image":"http:\/\/1indya.com\/cuponsninja\/wp-content\/uploads\/2017\/08\/section_image_narrow2-1.jpg",
         "image2":"http:\/\/1indya.com\/cuponsninja\/wp-content\/uploads\/2017\/08\/section_image_narrow2-1.jpg",
         "image3":"http:\/\/1indya.com\/cuponsninja\/wp-content\/uploads\/2017\/08\/poster_bg_1.jpg"
      },
      {
         "id":1236,
         "deal_type":"coupon",
         "coupon_title":"xyz",
         "coupon_code":"ABCDEF",
         "start_date":"August 10, 2017",
         "expiring_date":"August 10, 2017",
         "url":"google.com",
         "redeem_url":"groupon.com",
         "share_url":"groupon.com",
         "longitude":"78.4867",
         "latitude":"17.3850",
         "phone":"7049560282",
         "email":"nahat@gmail.om",
         "city":"Hyderabad",
         "address":"Hyderabad Biriyani",
         "current_week":"true",
         "store":"groupon.com",
         "store_logo":null,
         "store_url":"www.google.com",
         "category":"Food",
         "company":"Freelancer",
         "steps":"",
         "rules":"",
         "more_info":"",
         "deal_summary":"Promotional value expires Sep 10, 2017. Expires September 10, 2017. Valid only for option purchased. Ticket redeemable only for admission until expiration date, notwithstanding anything on the voucher; ticket has no value after expiration date passes. Refundable only on day of purchase through Groupon. Merchant is the issuer of ticket. Height\/physical restrictions may apply on rides. Excludes separately ticketed events and attractions. WOF reserves the right to close for private events. Attraction availability is subject to change without notice. Limit 10 per person. Merchant is solely responsible to purchasers for the care and quality of the advertised goods and services. Offer is not eligible for our promo codes or other discounts.",
         "image":null,
         "image2":null,
         "image3":null
      },
      {
         "id":1227,
         "deal_type":"coupon",
         "coupon_title":"Test Coupon",
         "coupon_code":"fg345",
         "start_date":"August 25, 2017",
         "expiring_date":"August 13, 2017",
         "url":"gogle.com",
         "redeem_url":"test",
         "share_url":"test",
         "longitude":"78.4867",
         "latitude":"17.3850",
         "phone":"5435435",
         "email":"nahat@gmail.om",
         "city":"inore",
         "address":"teste",
         "current_week":"true",
         "store":"groupon.com",
         "store_logo":null,
         "store_url":"www.groupon.com",
         "category":"Beauty",
         "company":"Coffee",
         "steps":"tetet",
         "rules":"test",
         "more_info":"tets",
         "deal_summary":"Promotional value expires Sep 10, 2017. Expires September 10, 2017. Valid only for option purchased. Ticket redeemable only for admission until expiration date, notwithstanding anything on the voucher; ticket has no value after expiration date passes. Refundable only on day of purchase through Groupon. Merchant is the issuer of ticket. Height\/physical restrictions may apply on rides. Excludes separately ticketed events and attractions. WOF reserves the right to close for private events. Attraction availability is subject to change without notice. Limit 10 per person. Merchant is solely responsible to purchasers for the care and quality of the advertised goods and services. Offer is not eligible for our promo codes or other discounts.",
         "image":"http:\/\/1indya.com\/cuponsninja\/wp-content\/uploads\/2017\/08\/20110125-appstore.jpg",
         "image2":"http:\/\/1indya.com\/cuponsninja\/wp-content\/uploads\/2017\/08\/20110125-appstore.jpg",
         "image3":"http:\/\/1indya.com\/cuponsninja\/wp-content\/uploads\/2017\/08\/poster_bg_1.jpg"
      },
      {
         "id":659,
         "deal_type":"coupon",
         "coupon_title":"Weight Loss Fitness",
         "coupon_code":"JSFFPWHS652",
         "start_date":"August 18, 2017",
         "expiring_date":"October 20, 2015",
         "url":"https:\/\/www.google.com",
         "redeem_url":"www.groupon.com",
         "share_url":"www.groupon.com",
         "longitude":"78.4867",
         "latitude":"17.3850",
         "phone":"8989898989",
         "email":"",
         "city":"Hyderabd",
         "address":"B 166 Prakruthi Nivas",
         "current_week":"true",
         "store":"zamato.com",
         "store_logo":null,
         "store_url":"zamato.com",
         "category":"Food",
         "company":"Freelancer",
         "steps":"1.Open google.com , 2.Enter the code",
         "rules":"1.Open google.com , 2.Enter the code",
         "more_info":"1.Open google.com , 2.Enter the code",
         "deal_summary":"This is a short description of the deal. For those who have seen the Earth from space, and for the hundreds and perhaps thousands more who will, the experience most certainly changes your perspective. The things that we share in our world are far more valuable than those which divide us.",
         "image":"http:\/\/1indya.com\/cuponsninja\/wp-content\/uploads\/2015\/09\/weight-loss-skinny-lose-.jpg",
         "image2":"http:\/\/1indya.com\/cuponsninja\/wp-content\/uploads\/2015\/09\/weight-loss-skinny-lose-.jpg",
         "image3":null
      }
   ];

var fildata
   let filtered = () =>{
      fildata = data.filter(one=>{
        return one.city=='Hyderabad';
      });
   }

   let reduced = () =>{
     fildata = data.reduce((msg, one)=>{
       return msg + (data.indexOf(one) + 1) + '...' + one.coupon_title + '...';
     }, '');
   }



   let currentCouponAPI = () => {
     console.log('Calling Current Coupon API');
     request({
       "method":"GET",
       "uri": 'http://1indya.com/cuponsninja/json-coupon-data/',
       "json": true,
       "headers": {
         "User-Agent": "Request-Promise"
       }
     }).then(function (res) {
       console.log('Success');
       console.log(res.DATA);
     },function (err) {
       console.log('Error');
       console.log(err);
   });
   };

   currentCouponAPI();
