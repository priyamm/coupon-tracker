'use strict';

const WELCOME = 'Welcome to the OneIndia Coupons...  Its my pleasure to check the coupons near you . Which city you are in currently?';
const HELP = 'Answer in the following way, I live in New Delhi ... or ... my city is New Delhi ... or ... New Delhi city.';

module.exports = {
  'WELCOME' : WELCOME,
  'HELP' : HELP
};
