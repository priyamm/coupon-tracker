'use strict';

const WELCOME = 'Welcome to the OneIndia Coupons...  Its my pleasure to check the coupons near you . Which city coupons would you like to check?';
const HELP = 'You can provide your city in the following manner like ... I live in New York or My city is New York.';

module.exports = {
  'WELCOME' : WELCOME,
  'HELP' : HELP
};
